package com.example.projetoavaliativo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
