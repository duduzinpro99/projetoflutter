import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora de Watts',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  TextEditingController currentController = TextEditingController();
  TextEditingController voltageController = TextEditingController();
  double result = 0.0;

  void calculateWatts() {
    double current = double.tryParse(currentController.text) ?? 0.0;
    double voltage = double.tryParse(voltageController.text) ?? 0.0;
    setState(() {
      result = current * voltage;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculadora de Watts'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextField(
              controller: currentController,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Corrente (Ampères)',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: voltageController,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Tensão (Volts)',
              ),
            ),
            SizedBox(height: 32.0),
            ElevatedButton(
              onPressed: calculateWatts,
              child: Text('Calcular'),
            ),
            SizedBox(height: 16.0),
            Text(
              'Potência em Watts: ${result.toStringAsFixed(2)} W',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
